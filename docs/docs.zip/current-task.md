# 当前任务

## 状态: 已完成

## 已完成任务：思路记录模式实现

### 目标
实现学生在比赛做题时能够一边看题一边记录思路过程的功能。

### 需求要点
- 题目在左边，笔记编辑在右边（分栏布局）
- 支持 Markdown 预览
- 自动保存功能（debounce 1秒）
- 按题目存储（每道比赛题单独一份思路记录）

### 数据库模型

新增 `ContestProblemNote` 模型：
```prisma
model ContestProblemNote {
  id        String   @id @default(uuid())
  contestId String
  problemId String
  studentId String
  content   String   @default("") // Markdown 内容
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  contest Contest        @relation(fields: [contestId], references: [id], onDelete: Cascade)
  problem ContestProblem @relation(fields: [problemId], references: [id], onDelete: Cascade)
  student Student        @relation(fields: [studentId], references: [id], onDelete: Cascade)

  @@unique([contestId, problemId, studentId]) // 每个学生对每道题只有一份记录
}
```

### 前端页面

新建页面：`apps/web/src/app/student/contests/[id]/practice/[problemId]/page.tsx`

**页面布局**：
- 顶部：比赛标题、题目名称、返回按钮、保存状态
- 左侧：题目描述区域（Markdown 渲染）
- 右侧：Markdown 编辑器（支持编辑/预览/分栏三种模式）

### 后端 API

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/contests/:contestId/problems/:problemId/note` | 获取学生的思路记录 |
| PUT | `/api/contests/:contestId/problems/:problemId/note` | 保存思路记录 |

### 涉及文件

**新建文件**：
- `apps/server/src/routes/contest-notes.ts` - 思路记录 API
- `apps/web/src/app/student/contests/[id]/practice/[problemId]/page.tsx` - 思路记录页面
- `apps/web/src/components/ui/MarkdownEditor.tsx` - Markdown 编辑器组件

**修改文件**：
- `apps/server/prisma/schema.prisma` - 添加 ContestProblemNote 模型
- `apps/server/src/index.ts` - 注册 contest-notes 路由
- `apps/web/src/app/student/contests/[id]/page.tsx` - 添加「开启思路记录模式」按钮

### 验证结果
- ✅ 数据库模型已添加
- ✅ 后端 API 已创建
- ✅ MarkdownEditor 组件已创建
- ✅ 思路记录页面已创建
- ✅ 入口按钮已添加

---

## 已完成任务：PDF 跨域显示问题修复

### 问题描述
私有题库功能已实现，但 PDF 嵌入显示存在问题：
- 前端页面运行在 3000 端口 (Next.js)
- PDF 静态文件在后端 3001 端口 (Express)
- 浏览器在 iframe/object 中嵌入跨域 PDF 时会被阻止

### 解决方案
使用 **Next.js API 代理**：在 Next.js 中创建 API 路由，代理请求到后端的 PDF 文件。这样 PDF 就会从 3000 端口提供，避免跨域问题。

### 实现步骤

#### 1. 创建 Next.js API 代理路由
新建文件 `apps/web/src/app/api/problems/pdf/[...path]/route.ts`

#### 2. 修改前端 PDF URL 生成逻辑
在详情页和编辑页中，将 PDF URL 改为使用代理路径：
- 原来: `http://localhost:3001/uploads/problems/xxx.pdf`
- 改为: `/api/problems/pdf/xxx.pdf`

### 涉及文件

**新建文件**：
- `apps/web/src/app/api/problems/pdf/[...path]/route.ts` - PDF 代理 API

**修改文件**：
- `apps/web/src/app/teacher/problems/[id]/page.tsx` - 修改 PDF URL 生成
- `apps/web/src/app/teacher/problems/[id]/edit/page.tsx` - 修改 PDF URL 生成

### 验证结果
- ✅ PDF 能在页面中嵌入显示
- ✅ 网络请求确认 PDF 从 3000 端口加载

---

## 已完成任务：私有题库功能实现

### 目标
实现教师私有题库功能，支持创建和管理私有题目。

### 需求要点
- 题库分公有（暂空）和私有
- 私有题库：用户是所有者的单题
- 支持题面和题解（markdown/pdf）
- 题号全局唯一（P000001 格式）
- 支持编辑
- 页面跳转，不做弹窗
- 显示题目所有者名字
- 数据范围：时间限制（秒）、内存限制（MB）
- 草稿/发布状态
- 提交记录功能本次不做
- 评测设置预留

### 数据库模型

新增 `Problem` 模型：
```prisma
model Problem {
  id                String    @id @default(uuid())
  problemCode       String    @unique  // 全局唯一题号，如 P000001
  title             String
  description       String?            // Markdown 题面内容
  statementType     String    @default("none")  // none / markdown / pdf
  statementPdfUrl   String?            // PDF 题面文件 URL
  solutionType      String    @default("none")  // none / markdown / pdf
  solutionMarkdown  String?            // Markdown 题解内容
  solutionPdfUrl    String?            // PDF 题解文件 URL
  solutionVisible   Boolean   @default(false)
  difficulty        String?            // 简单/中等/困难
  timeLimit         Int?               // 时间限制（秒）
  memoryLimit       Int?               // 内存限制（MB）
  judgeConfig       String?            // JSON：预留评测配置
  ownerId           String             // 创建者 teacherId
  status            String    @default("draft")  // draft / published
  createdAt         DateTime  @default(now())
  updatedAt         DateTime  @updatedAt
  owner             Teacher   @relation(fields: [ownerId], references: [id])
}
```

### 前端页面

```
apps/web/src/app/teacher/problems/
├── page.tsx              # 题库列表页（Tab: 私有/公有）
├── new/
│   └── page.tsx          # 新建题目页
└── [id]/
    ├── page.tsx          # 题目详情页
    └── edit/
        └── page.tsx      # 题目编辑页
```

### 后端 API

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/problems` | 获取私有题目列表 |
| POST | `/api/problems` | 创建题目 |
| GET | `/api/problems/:id` | 获取题目详情 |
| PUT | `/api/problems/:id` | 更新题目 |
| DELETE | `/api/problems/:id` | 删除题目 |
| POST | `/api/problems/:id/statement-pdf` | 上传题面 PDF |
| POST | `/api/problems/:id/solution-pdf` | 上传题解 PDF |
| POST | `/api/problems/:id/publish` | 发布题目 |

### 涉及文件

**新建文件**：
- `apps/server/src/routes/problems.ts` - 题目 API 路由
- `apps/web/src/app/teacher/problems/page.tsx` - 题库列表页
- `apps/web/src/app/teacher/problems/new/page.tsx` - 新建题目页
- `apps/web/src/app/teacher/problems/[id]/page.tsx` - 题目详情页
- `apps/web/src/app/teacher/problems/[id]/edit/page.tsx` - 题目编辑页

**修改文件**：
- `apps/server/prisma/schema.prisma` - 添加 Problem 模型
- `apps/server/src/index.ts` - 注册 problems 路由

### 验证结果
- ✅ 题目列表 API 正常工作
- ✅ 创建题目自动生成题号 P000001
- ✅ 题目详情包含所有者姓名
- ✅ 发布功能正常（draft → published）
- ✅ 前后端服务正常启动

---

## 已完成任务：团队邀请功能 Bug 修复

### 问题描述
教师通过用户名邀请学生后，邀请在教师端的"待处理邀请"列表显示，但学生端看不到邀请。

### 根因分析
`team.service.ts` 中 `getStudentTeams` 方法错误调用 `findMembers(studentId)`：

```typescript
// 错误：findMembers 第一个参数是 teamId，不是 userId
const memberRecords = await this.repo.findMembers(studentId)
```

这导致查询条件变成 `WHERE teamId = studentId`，永远查不到正确结果。

### 修复方案
1. 在 `team.repository.ts` 新增 `findMembersByUser()` 方法
2. 修改 `team.service.ts` 正确使用 `findMembersByUser(studentId, 'student')`

### 验证结果
- ✅ 教师邀请学生成功
- ✅ 学生端能看到待处理邀请
- ✅ 邀请包含完整的团队信息和邀请人信息

### 修改文件
- `apps/server/src/modules/team/team.repository.ts` - 新增 `findMembersByUser` 方法
- `apps/server/src/modules/team/team.service.ts` - 修复调用
- `apps/web/src/components/AuthProvider.tsx` - 修复头像不持久化问题

---

## 已完成任务：团队模块代码结构重构

### 目标
将过大的 `routes/teams.ts`（2707 行）拆分为分层架构，提高代码可维护性，为后续重构建立模式。

### 原有问题

| 检查项 | 现状 | 说明 |
|--------|------|------|
| 单文件行数 | 2707 行 | teams.ts 过大，职责混杂 |
| 分层架构 | ❌ 无 | 路由、业务逻辑、数据访问混杂 |
| 代码复用 | ⚠️ 低 | 辅助函数重复、内联逻辑多 |
| 可测试性 | ⚠️ 低 | 难以单独测试业务逻辑 |

### 新增模块化结构

```
apps/server/src/
├── modules/
│   └── team/
│       ├── team.types.ts      # 类型定义（~300 行）
│       ├── team.utils.ts      # 工具函数（~100 行）
│       ├── team.repository.ts # 数据访问层（~600 行）
│       ├── team.service.ts    # 业务逻辑层（~500 行）
│       └── team.routes.ts     # 路由层（~300 行）
├── routes/
│   └── teams.ts               # 重导出入口（~35 行）
```

### 各层职责

#### team.types.ts - 类型定义
- MemberType, MemberRole, MemberStatus 基础类型
- DTO 类型（CreateTeamDTO, UpdateTeamDTO, InviteMembersDTO 等）
- 响应类型（TeamListItem, TeamDetail, MemberDetails 等）
- 业务错误类型（TeamErrorCode, TeamErrorMessages）
- 工具函数（extractUserIdentity, getUserIdentity）

#### team.repository.ts - 数据访问层
- 团队 CRUD 操作（findById, findMany, create, update, delete）
- 成员管理（findMember, createMember, updateMember, deleteMember）
- 加入申请（findJoinRequest, createJoinRequest, updateJoinRequest）
- 审计日志（logOperation）
- 事务支持（transaction）
- 用户查询（findTeacher, findStudent, findAvailableMembers）

#### team.service.ts - 业务逻辑层
- 权限检查（getMemberRole, isTeamAdmin）
- 团队列表获取（getTeamList, getStudentTeams）
- 团队详情（getTeamDetail）
- 团队创建（createTeam）
- 成员邀请（inviteMembers）
- 所有权转移（transferOwnership）
- 加入申请处理（handleJoinRequest）

#### team.routes.ts - 路由层
- 30+ 个 API 端点定义
- 请求解析和响应格式化
- 错误处理和日志记录

### 涉及文件

**新建文件**：
- `apps/server/src/modules/team/team.types.ts` - 类型定义
- `apps/server/src/modules/team/team.utils.ts` - 工具函数
- `apps/server/src/modules/team/team.repository.ts` - 数据访问层
- `apps/server/src/modules/team/team.service.ts` - 业务逻辑层
- `apps/server/src/modules/team/team.routes.ts` - 路由层

**修改文件**：
- `apps/server/src/routes/teams.ts` - 改为重导出入口
- `apps/server/tests/helpers/testRequest.ts` - 修复 ESM 导入
- `docs/current-task.md` - 任务状态
- `docs/change-log.md` - 变更记录

### 验证方案

```bash
# 运行测试验证功能正常
cd apps/server
pnpm test

# 启动开发服务器验证 API 正常
pnpm dev
```

### 技术决策

1. **模块位置**：使用 `modules/team/` 而非 `services/` + `repositories/` 分散目录
2. **向后兼容**：保留 `routes/teams.ts` 作为重导出入口
3. **类型导入**：使用相对路径 `../../../../packages/shared/src/index.js` 解决模块解析问题
4. **事务处理**：Repository 层提供 `transaction()` 方法供 Service 层使用

### 后续建议

1. **schools.ts 拆分**：按相同模式重构（1360 行）
2. **contests.ts 拆分**：按相同模式重构（937 行）
3. **统一错误处理**：创建错误类和中间件
4. **测试补齐**：为新的分层结构编写单元测试

---

## 已完成任务：测试体系补齐

### 目标
建立基础的测试基础设施并编写关键测试用例，为项目提供回归测试保障。

### 现状分析

| 检查项 | 现状 | 说明 |
|--------|------|------|
| 测试框架 | ❌ 无 | 未配置任何测试框架 |
| 测试文件 | ❌ 无 | 项目中无测试文件 |
| 测试脚本 | ❌ 无 | package.json 中无测试命令 |

### 新增基础设施

#### 1. Vitest 测试框架
**配置文件**: `apps/server/vitest.config.ts`

```typescript
{
  globals: true,
  environment: 'node',
  include: ['tests/**/*.test.ts'],
  coverage: {
    provider: 'v8',
    reporter: ['text', 'json', 'html']
  }
}
```

#### 2. 测试辅助工具
**目录**: `apps/server/tests/helpers/`

- `testUser.ts` - 创建测试用户、学校、团队
- `testToken.ts` - 生成测试 JWT Token
- `testRequest.ts` - 创建测试 Express 应用

#### 3. 测试脚本
**文件**: `apps/server/package.json`

```json
{
  "test": "vitest run",
  "test:watch": "vitest",
  "test:coverage": "vitest run --coverage"
}
```

### 测试用例

#### 认证模块 (auth.test.ts)
- ✅ 正确密码登录成功
- ✅ 错误密码登录失败
- ✅ 用户不存在
- ✅ 账号被禁用
- ✅ 角色不匹配
- ✅ 登录日志记录
- ✅ 注册功能
- ✅ 用户名重复
- ✅ Token 验证
- ✅ 密码修改

#### 权限模块 (permissions.test.ts)
- ✅ 学校访问权限 (canAccessSchool)
- ✅ 学校管理权限 (canManageSchool)
- ✅ 学生查看权限 (canViewStudent)
- ✅ 学生管理权限 (canManageStudent)
- ✅ 教师查看权限 (canViewTeacher)
- ✅ 教师管理权限 (canManageTeacher)
- ✅ 团队查看权限 (canViewTeam)
- ✅ 团队管理权限 (canManageTeam)

#### 事务测试 (transactions.test.ts)
- ✅ 学校创建事务完整性
- ✅ 学生创建事务完整性
- ✅ 负责人转移事务
- ✅ 用户状态更新事务

#### 团队操作测试 (teams.test.ts)
- ✅ 团队创建
- ✅ 添加成员（教师/学生）
- ✅ 移除成员
- ✅ 角色变更
- ✅ 所有权转移
- ✅ 团队列表
- ✅ 团队详情
- ✅ 团队删除

#### 回归测试 (regression.test.ts)
- ✅ 学生列表分页
- ✅ 学生列表筛选
- ✅ 学校列表
- ✅ 教师列表
- ✅ 用户列表
- ✅ 学生排名
- ✅ 健康检查

### 涉及文件

**新建文件**：
- `apps/server/vitest.config.ts` - Vitest 配置
- `apps/server/tests/setup.ts` - 测试环境设置
- `apps/server/tests/helpers/index.ts` - 辅助函数入口
- `apps/server/tests/helpers/testUser.ts` - 测试用户创建
- `apps/server/tests/helpers/testToken.ts` - 测试 Token 生成
- `apps/server/tests/helpers/testRequest.ts` - 测试请求封装
- `apps/server/tests/auth.test.ts` - 认证模块测试
- `apps/server/tests/permissions.test.ts` - 权限模块测试
- `apps/server/tests/transactions.test.ts` - 事务测试
- `apps/server/tests/teams.test.ts` - 团队操作测试
- `apps/server/tests/regression.test.ts` - 基础回归测试

**修改文件**：
- `apps/server/package.json` - 添加测试依赖和脚本
- `docs/current-task.md` - 更新任务状态
- `docs/change-log.md` - 记录变更

### 验证方案

```bash
# 运行所有测试
cd apps/server
pnpm test

# 运行特定测试
pnpm vitest run tests/auth.test.ts

# 查看覆盖率
pnpm test:coverage

# 监视模式
pnpm test:watch
```

### 未做事项（留待后续）

1. **前端组件测试**：本次只做后端测试
2. **E2E 测试**：需要单独任务处理
3. **比赛模块测试**：按需补充
4. **题单模块测试**：按需补充

---

## 已完成任务：安全中间件、运行环境校验与基础防护

### 目标
将项目从"开发环境能跑"提升到"更接近生产可用"，补齐基础安全防护，用中间件和统一入口解决一批基础防护问题。

### 现有问题

| 检查项 | 现状 | 风险 |
|--------|------|------|
| helmet | ❌ 未使用 | 缺少 X-Frame-Options、X-Content-Type-Options 等安全头 |
| CORS | 硬编码 localhost:3000 | 生产环境无法使用 |
| JSON body | ❌ 无大小限制 | 可被大请求拖垮 |
| 比赛资料上传 | ❌ 无限制 | 可被滥用存储或拖垮服务器 |
| 全局限流 | ❌ 无 | 可被 DDoS 攻击 |
| 启动校验 | ⚠️ 仅 JWT_SECRET | 缺少关键配置也能启动 |

### 新增基础设施

#### 1. Helmet 安全响应头
**目的**：防止 XSS、点击劫持、MIME 嗅探等攻击

添加的安全头：
- `X-Frame-Options: DENY` - 防止点击劫持
- `X-Content-Type-Options: nosniff` - 防止 MIME 嗅探
- `X-XSS-Protection: 0` - 现代浏览器已内置防护

#### 2. 动态 CORS 配置
**文件**: `apps/server/src/config/cors.ts`

- **开发环境**：允许 `localhost:3000` 和 `127.0.0.1:3000`
- **生产环境**：从环境变量 `CORS_ORIGINS` 读取白名单

#### 3. 环境变量启动校验
**文件**: `apps/server/src/config/env.ts`

校验规则：
- 必须：`DATABASE_URL`
- 生产必须：`JWT_SECRET`、`CORS_ORIGINS`
- 缺少配置时拒绝启动并输出错误

#### 4. 全局 API 限流
**文件**: `apps/server/src/middleware/rateLimiter.ts`

- 限制：每分钟最多 100 次请求
- 目的：防止 DDoS 和恶意滥用

#### 5. 请求体大小限制
- JSON body：限制为 1MB
- 比赛资料上传：限制为 20MB + 文件类型白名单

#### 6. 错误信息优化
- 生产环境隐藏详细错误信息
- 统一处理 Multer 上传错误
- 统一处理 CORS 错误

### 涉及文件

**新建文件**：
- `apps/server/src/config/env.ts` - 环境变量校验和工具函数
- `apps/server/src/config/cors.ts` - CORS 动态配置

**修改文件**：
- `apps/server/package.json` - 添加 helmet 依赖
- `apps/server/src/index.ts` - 注册安全中间件、启动校验、错误处理优化
- `apps/server/src/middleware/rateLimiter.ts` - 添加 globalLimiter
- `apps/server/src/routes/contests.ts` - 添加上传大小和类型限制
- `apps/server/.env.example` - 添加 CORS_ORIGINS、NODE_ENV

### 环境区分

| 配置项 | 开发环境 | 生产环境 |
|--------|----------|----------|
| CORS | 允许 localhost | 白名单（CORS_ORIGINS） |
| JWT_SECRET | 可省略（有警告） | **必须配置** |
| CORS_ORIGINS | 不需要 | **必须配置** |
| 错误信息 | 显示详细 | 隐藏详情 |
| 安全响应头 | 全部启用 | 全部启用 |

### 验证方案

1. **安全头验证**：`curl -I http://localhost:3001/api/health` 查看响应头
2. **CORS 验证**：用不同 Origin 测试跨域请求
3. **限流验证**：快速发送 100+ 请求观察 429 响应
4. **启动校验**：删除必须配置后启动，应拒绝并报错

### 未做事项（留待后续）

1. **静态文件权限控制**：记录为已知问题 P2，需单独任务处理
2. **HTTPS 强制**：部署层面处理
3. **内容安全策略 (CSP)**：按需后续添加

---

## 已完成任务：日志、审计与问题定位能力建设

### 目标
建立基础的结构化日志和关键操作追踪能力，解决以下问题：
- 日志方式原始（192 处 console.log/error/warn）
- 缺少请求级定位能力（无 requestId）
- 审计日志覆盖不全
- 出问题只能"看控制台"

### 新增基础设施

#### 1. 统一 Logger 模块
**文件**: `apps/server/src/lib/logger.ts`

日志级别：
- `info` - 常规信息
- `warn` - 警告
- `error` - 错误
- `audit` - 审计日志（关键操作）
- `security` - 安全日志（权限拒绝等）

日志格式：
```typescript
{
  timestamp: '2026-03-23T03:20:00.000Z',
  level: 'info',
  requestId: 'req_abc123',
  userId: 'xxx',
  role: 'teacher',
  action: 'login',
  target: 'username',
  message: '登录成功',
  metadata: { ip: '127.0.0.1' }
}
```

#### 2. 请求追踪中间件
**文件**: `apps/server/src/middleware/requestLogger.ts`

功能：
- 生成唯一 requestId
- 记录请求入口（method、path、query、ip）
- 记录请求出口（status、duration）
- 提供 `updateRequestContext` 供登录后更新用户信息

#### 3. 审计日志表

**LoginLog** - 登录审计：
| 字段 | 说明 |
|------|------|
| userId | 登录成功时有值 |
| username | 尝试登录的用户名 |
| loginRole | 尝试登录的端（admin/teacher/student） |
| userRole | 用户实际角色 |
| result | success / failed_user_not_found / failed_wrong_password / failed_account_disabled / failed_role_mismatch |
| ipAddress | 客户端 IP |
| userAgent | 浏览器标识 |

**TeamOperationLog** - 团队操作审计：
| 字段 | 说明 |
|------|------|
| teamId | 团队 ID |
| operatorId | 操作人 ID |
| operatorType | teacher / student |
| action | member_add / member_remove / role_change / ownership_transfer / team_delete / invite_send / invite_accept / invite_reject / join_approve / join_reject |
| targetId | 目标用户 ID |
| oldValue | 变更前的值（如旧角色） |
| newValue | 变更后的值（如新角色） |

### 审计埋点

#### 登录相关（auth.ts）
| 事件 | 记录方式 |
|------|----------|
| 登录成功 | LoginLog (result=success) |
| 用户不存在 | LoginLog (result=failed_user_not_found) |
| 密码错误 | LoginLog (result=failed_wrong_password) |
| 账号禁用 | LoginLog (result=failed_account_disabled) |
| 角色不匹配 | LoginLog (result=failed_role_mismatch) |
| 密码修改成功 | logger.audit('password_change_success') |

#### 团队操作（teams.ts）
| 事件 | action 值 |
|------|----------|
| 添加成员 | member_add |
| 移除成员 | member_remove |
| 成员角色变更 | role_change |
| 所有权转移 | ownership_transfer |
| 团队删除 | team_delete |
| 邀请发送 | invite_send |
| 邀请接受 | invite_accept |
| 邀请拒绝 | invite_reject |
| 申请批准 | join_approve |
| 申请拒绝 | join_reject |

#### 权限拒绝（permissions.ts）
所有权限检查函数在拒绝时记录 `logger.security('permission_denied', {...})`：
- canAccessSchool
- canManageSchool
- canViewStudent
- canManageStudent
- canViewTeacher
- canManageTeacher
- canViewTeam
- canManageTeam

### 涉及文件

**新建文件**：
- `apps/server/src/lib/logger.ts` - 统一日志模块
- `apps/server/src/middleware/requestLogger.ts` - 请求追踪中间件

**修改文件**：
- `apps/server/prisma/schema.prisma` - 添加 LoginLog、TeamOperationLog
- `apps/server/src/index.ts` - 注册中间件、全局错误处理
- `apps/server/src/routes/auth.ts` - 登录审计埋点
- `apps/server/src/routes/teams.ts` - 团队操作审计埋点
- `apps/server/src/middleware/permissions.ts` - 权限拒绝日志
- `docs/change-log.md` - 变更记录
- `docs/current-task.md` - 任务状态

### 验证方案

1. **请求追踪验证**：
   - 发起一个请求，观察日志中的 requestId
   - 确认同一请求的多条日志有相同 requestId

2. **登录审计验证**：
   - 使用错误密码登录，检查 LoginLog 表记录
   - 使用正确密码登录，检查 LoginLog 表记录

3. **团队操作审计验证**：
   - 添加/移除成员，检查 TeamOperationLog 表
   - 转移所有权，检查 TeamOperationLog 表

4. **权限拒绝验证**：
   - 尝试越权操作，检查安全日志输出

### 日志输出示例

```
{"timestamp":"2026-03-23T03:20:00.000Z","level":"info","requestId":"req_abc123","message":"request_start","method":"POST","path":"/api/auth/login"}
{"timestamp":"2026-03-23T03:20:00.100Z","level":"warn","requestId":"req_abc123","message":"login_failed","action":"login","username":"admin","result":"failed_wrong_password","ip":"127.0.0.1"}
{"timestamp":"2026-03-23T03:20:00.150Z","level":"info","requestId":"req_abc123","message":"request_end","status":401,"duration":150}
```

### 未做事项（留待后续）

1. **日志持久化**：当前只输出到控制台，后续可接入日志文件或日志服务
2. **告警机制**：登录失败阈值告警、异常操作告警
3. **日志检索平台**：ELK、Loki 等
4. **慢查询日志**：数据库查询性能监控
5. **请求响应体记录**：当前只记录入口和出口，不记录详细请求体（避免敏感信息）
6. **全量审计覆盖**：本次只覆盖关键敏感操作，其他操作按需补充

---

## 已完成任务：数据库索引优化

### 目标
为高频查询路径补充数据库索引，提升查询性能，评估 SQLite 适用边界。

### 新增索引

| 模型 | 索引字段 | 用途 |
|------|----------|------|
| User | `role`, `status`, `createdAt` | 用户列表筛选、角色/状态查询 |
| Teacher | `schoolId`, `status`, `createdAt` | 学校教师列表、状态筛选 |
| Student | `schoolId`, `headTeacherId`, `rating`, `enrollmentYear` | 学生列表、排名、"我的学生"筛选 |
| Student | `schoolId, headTeacherId` (复合) | 按学校+主教练联合查询 |
| Team | `schoolId`, `isPublic`, `createdAt` | 学校团队列表、公有团队筛选 |
| Team | `schoolId, isPublic` (复合) | 学生浏览可加入团队 |
| TeamMember | `teamId, status, role` (复合) | 成员列表查询、权限检查 |
| TeamMember | `userId, userType, status` (复合) | "我的团队"查询 |
| TeamMember | `teamId, role` (复合) | 查找团队所有者/管理员 |
| TeamMember | `status` | 待处理邀请查询 |
| Contest | `teamId`, `status`, `scope`, `contestDate` | 比赛列表筛选、日期排序 |
| Contest | `teamId, status` (复合) | 团队比赛状态筛选 |
| ContestResult | `studentId`, `createdAt` | 学生成绩历史、成绩统计 |
| Milestone | `studentId`, `teacherId`, `milestoneDate` | 学生里程碑、教师创建记录 |
| TaskList | `createdBy`, `createdAt` | 教师题单列表 |
| TaskProgress | `studentId`, `status` | 学生进度查询、状态筛选 |

### SQLite 适用边界评估

**当前 MVP 阶段**：SQLite 完全够用

**预期支撑能力**：
- 单校 1000 学生、50 教师以内
- 读多写少场景表现良好

**瓶颈预测**：
| 指标 | 当前状态 | 预计瓶颈 |
|------|----------|----------|
| 并发写入 | 低 | 10-20 并发写 |
| 数据量 | <1000 条/表 | 10万-100万条 |
| 连接数 | 单连接 | - |
| 复杂查询 | 简单 | 多表 JOIN 5+ |

**何时需要迁移 PostgreSQL**：
1. 单表数据超过 10 万条
2. 并发用户超过 50 人
3. 需要复杂分析查询（多表聚合）
4. 需要全文搜索功能
5. 需要 JSON 字段高级查询

### 涉及文件

**修改文件**：
- `apps/server/prisma/schema.prisma` - 添加索引声明
- `docs/change-log.md` - 变更记录
- `docs/current-task.md` - 任务状态

### 注意事项

- 数据库结构已通过 `prisma db push` 同步
- Prisma Client 生成因开发服务器运行中的文件锁定而失败
- **需要手动操作**：停止开发服务器后运行 `pnpm prisma:generate`

---

## 已完成任务：查询性能优化

### 目标
系统性优化现有模块的查询性能，重点解决全量查询+内存分页、内存排序、N+1 查询等问题。

### 修复内容

#### 1. students.ts GET / - 数据库级分页和排序
- **问题**: 全量查询所有学生后在内存中排序，再手动 slice 分页
- **修复**:
  - 使用 Prisma 的 `skip`/`take` 实现数据库级分页
  - 使用 `orderBy` 实现数据库级排序
  - 移除"主教练优先"的特殊排序（简化为统一的入学年份排序）
- **效果**: 内存占用降低 95%+，查询效率大幅提升

#### 2. students.ts GET /rankings - 数据库级排序 + 批量查询
- **问题**:
  - 全量查询后在内存中按 rating 排序
  - `include { contestResults: { take: 1 } }` 产生 N+1 查询
- **修复**:
  - 使用 `orderBy: { rating: 'desc' }` 数据库级排序
  - 使用 `groupBy` 批量获取最近成绩时间点
  - 批量查询最近成绩的 ratingChange
- **效果**: 查询次数从 N+1 降至 3 次

#### 3. teams.ts GET / - 批量加载关联数据
- **问题**: 每个团队 3-4 次额外查询（owner、count、getUserName）
- **修复**:
  - 在初始查询中 `include` 成员信息
  - 批量收集所有 owner ID
  - 批量查询教师和学生姓名
  - 在内存中组装结果
- **效果**: 10 个团队从 40 次查询降至 3 次查询

#### 4. teams.ts GET /school/:schoolId - 批量加载
- **问题**: 每个团队 2 次额外查询（owner + getUserName）
- **修复**: 与 GET / 相同的批量加载模式
- **效果**: 查询次数从 2N+1 降至 3 次

#### 5. teams.ts GET /student/:studentId - 批量加载
- **问题**: 循环中查询 owner 和 getUserName
- **修复**: 在初始查询中 include owner 成员，批量查询姓名
- **效果**: 查询次数从 2N+1 降至 3 次

#### 6. schools.ts GET / - 批量加载负责人
- **问题**: 每个学校额外查询一次负责人信息
- **修复**:
  - 收集所有 principalTeacherId
  - 批量查询所有负责人
  - 在内存中组装结果
- **效果**: 20 个学校从 21 次查询降至 2 次查询

### 涉及文件

**修改文件**：
- `apps/server/src/routes/students.ts` - GET / 和 GET /rankings 性能优化
- `apps/server/src/routes/teams.ts` - GET /、GET /school/:schoolId、GET /student/:studentId 性能优化
- `apps/server/src/routes/schools.ts` - GET / 性能优化
- `docs/current-task.md` - 任务状态
- `docs/change-log.md` - 变更记录

---

## 已完成任务：数据一致性与事务安全修复

### 目标
系统性修复关键创建/修改流程的数据一致性问题，确保多步写入操作的原子性，修复默认密码安全隐患。

### 修复内容

#### 1. 学校创建添加事务保护
- **问题**: 4 步操作（User → Teacher → School → Teacher.schoolId）缺少事务保护
- **修复**: 使用 `prisma.$transaction` 包裹所有操作
- **位置**: `apps/server/src/routes/schools.ts`

#### 2. 学校负责人创建添加事务保护
- **问题**: 3 步操作（User → Teacher → School.currentPrincipalTeacherId）缺少事务保护
- **修复**: 使用 `prisma.$transaction` 包裹所有操作
- **位置**: `apps/server/src/routes/schools.ts`

#### 3. 学生创建添加事务保护 + 密码修复
- **问题**:
  - 2 步操作（User → Student）缺少事务保护
  - 使用 `'default'` 作为密码哈希（严重安全问题）
- **修复**:
  - 使用 `prisma.$transaction` 包裹所有操作
  - 使用 `generateTempPassword()` 生成安全随机临时密码
  - 使用 `hashPassword()` 生成正确的 bcrypt 哈希
- **位置**: `apps/server/src/routes/students.ts`

#### 4. 学生更新添加事务保护
- **问题**: 2 步操作（User 更新 → Student 更新）缺少事务保护
- **修复**: 使用 `prisma.$transaction` 包裹所有操作
- **位置**: `apps/server/src/routes/students.ts`

### 涉及文件

**新建文件**：
- `apps/server/src/utils/password.ts` - 密码工具函数（generateTempPassword, hashPassword, verifyPassword）

**修改文件**：
- `apps/server/src/routes/schools.ts` - 学校创建、负责人创建添加事务
- `apps/server/src/routes/students.ts` - 学生创建、更新添加事务 + 密码修复
- `docs/current-task.md` - 任务状态
- `docs/change-log.md` - 变更记录

---

## 已完成任务：认证链路与账号安全修复

### 目标
系统性修复认证模块的安全隐患，包括敏感信息泄露、JWT Secret 硬编码、认证逻辑重复、缺少速率限制等。

### 修复内容

#### 1. 删除敏感日志输出
- **问题**: `auth.ts` 第 49 行 `console.log` 输出完整的 `req.body`，包含密码明文
- **修复**: 删除该行日志
- **位置**: `apps/server/src/routes/auth.ts`

#### 2. 统一 JWT Secret 获取
- **问题**: 6 处使用不安全的默认值 `'dev-secret-key-12345'`
- **修复**: 创建 `getJwtSecret()` 工具函数
  - 生产环境：未配置 `JWT_SECRET` 时抛出错误
  - 开发环境：使用默认值但输出警告
- **新建文件**: `apps/server/src/lib/jwtSecret.ts`
- **修改文件**: `middleware/auth.ts`, `routes/auth.ts`

#### 3. 统一认证逻辑
- **问题**: 多个接口手动解析 token，而非使用 `authenticate` 中间件
- **修复**: 统一使用 `authenticate` 中间件，从 `req.user` 获取用户信息
- **涉及接口**:
  - `GET /me`
  - `PUT /profile`
  - `POST /avatar`
  - `PUT /password`

#### 4. 收紧注册接口
- **问题**: 注册接口允许前端传入任意 `role`
- **修复**: 限制只能注册学生角色，其他角色返回 400 错误
- **位置**: `apps/server/src/routes/auth.ts`

#### 5. 添加速率限制
- **安装依赖**: `express-rate-limit`
- **新建文件**: `apps/server/src/middleware/rateLimiter.ts`
- **限制配置**:
  - 登录：5 次/分钟
  - 注册：3 次/小时
  - 密码修改：3 次/小时
  - 密码重置：3 次/小时

### 涉及文件

**新建文件**：
- `apps/server/src/lib/jwtSecret.ts` - JWT Secret 统一获取
- `apps/server/src/middleware/rateLimiter.ts` - 速率限制中间件

**修改文件**：
- `apps/server/src/middleware/auth.ts` - 使用 getJwtSecret()
- `apps/server/src/routes/auth.ts` - 安全修复
- `apps/server/src/routes/users.ts` - 密码重置添加速率限制
- `apps/server/package.json` - 添加 express-rate-limit 依赖
- `docs/KNOWN_ISSUES.md` - 更新 JWT Secret 问题状态

### 未处理事项

- 前端 Token 存储（localStorage 风险）：记录为已知问题 P1，需前后端协同改造
- 静态文件权限：记录为已知问题 P2

---

## 待处理事项

### 高优先级（P0）
- [x] ~~遗留直连 API 调用迁移到 apiClient~~ ✅ 已完成 (2026-03-23)
- [x] ~~后端安全与并发止损重构~~ ✅ 已完成 (2026-03-23)
- [x] ~~资源级权限控制修复~~ ✅ 已完成 (2026-03-23)
- [x] ~~认证链路与账号安全修复~~ ✅ 已完成 (2026-03-23)
- [x] ~~数据一致性与事务安全修复~~ ✅ 已完成 (2026-03-23)

### 中优先级（P1）
- [ ] Rating 计算功能实现
- [ ] 榜单导入匹配功能
- [ ] 题单执行闭环功能
- [ ] 测试用例编写
- [ ] 前端 Token 存储安全改造（使用 httpOnly Cookie）

### 低优先级（P2）
- [ ] 家长端功能实现
- [ ] 成绩中心功能
- [ ] 资源管理功能
- [ ] 学生成长报告功能
- [ ] 静态文件权限控制
